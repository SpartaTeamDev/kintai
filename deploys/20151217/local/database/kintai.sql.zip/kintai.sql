-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2016 at 07:52 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kintai`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_audit`
--

CREATE TABLE `tbl_audit` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `information` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_address` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `params` text COLLATE utf8_unicode_ci,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE `tbl_country` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `alpha2_code` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alpha3_code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `immigration_code` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_code` smallint(5) UNSIGNED DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_currency`
--

CREATE TABLE `tbl_currency` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `iso4217_code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `country_code` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_currency`
--

INSERT INTO `tbl_currency` (`id`, `name`, `iso4217_code`, `symbol`, `rate`, `country_code`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'Japan, Yen', 'JPY', '¥', 102.61, 'JP', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(2, 'United States Of America, Dollars', 'USD', '$', 1, 'US', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(3, 'Viet Nam, Dong', 'VND', '₫', 22291.6, 'VN', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `province_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_language`
--

CREATE TABLE `tbl_language` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `iso6391_code` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_code` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_language`
--

INSERT INTO `tbl_language` (`id`, `name`, `iso6391_code`, `country_code`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'Chinese (PRC)', 'zh', 'CN', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(2, 'Spanish (Spain)', 'es', 'ES', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(3, 'English', 'en', 'GB', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(4, 'Hindi', 'hi', 'IN', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(5, 'Arabic (Saudi Arabia)', 'ar', 'SA', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(6, 'Portuguese (Portugal)', 'pt', 'PT', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(7, 'Russian', 'ru', 'RU', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(8, 'Japanese', 'ja', 'JP', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(9, 'Vietnamese', 'vi', 'VN', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lookup`
--

CREATE TABLE `tbl_lookup` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(10) UNSIGNED DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_media`
--

CREATE TABLE `tbl_media` (
  `id` int(10) UNSIGNED NOT NULL,
  `origin_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_ext` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` bigint(20) UNSIGNED DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_permission`
--

CREATE TABLE `tbl_permission` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_permission`
--

INSERT INTO `tbl_permission` (`id`, `name`, `description`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'Backend.Account', 'Allows you to manage users, roles and permissions.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(2, 'Backend.Account.Permission', 'Allows you to manage permissions.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(3, 'Backend.Account.Role', 'Allows you to manage roles.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(4, 'Backend.Account.User', 'Allows you to manage users.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(5, 'Backend.System', 'Allows you to manage audit trails, lookup values and settings.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(6, 'Backend.System.Audit', 'Allows you to manage audit trails.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(7, 'Backend.System.Lookup', 'Allows you to manage lookup values.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(8, 'Backend.System.Setting', 'Allows you to manage settings.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_permissions`
--

CREATE TABLE `tbl_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_province`
--

CREATE TABLE `tbl_province` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `number_plate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_code` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role`
--

CREATE TABLE `tbl_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_role`
--

INSERT INTO `tbl_role` (`id`, `name`, `description`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'Administrator', 'Members of the Administrator role have the largest amount of default permissions and the ability to change their own permissions.', NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:51:03', 'demo', 0, 3),
(2, 'Guest', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(3, 'Power User', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(4, 'User', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roles`
--

CREATE TABLE `tbl_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roles_permissions`
--

CREATE TABLE `tbl_roles_permissions` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role_permission`
--

CREATE TABLE `tbl_role_permission` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_role_permission`
--

INSERT INTO `tbl_role_permission` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(3, 1),
(3, 4),
(3, 5),
(3, 6),
(3, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_setting`
--

CREATE TABLE `tbl_setting` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_setting`
--

INSERT INTO `tbl_setting` (`id`, `name`, `value`, `description`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'copyright', 'Copyright 2016 by My Company. All Rights Reserved.', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(2, 'title', 'Admin Panel', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(3, 'defaultRoute', 'setting.index', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(4, 'imageAllowedExt', 'gif,jpeg,jpg,png', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(5, 'imageMaxSize', '2097152', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(6, 'datetimeFormat', 'Y-m-d H:i:s', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(7, 'dateFormat', 'Y-m-d', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(8, 'timeFormat', 'H:i:s', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(9, 'itemsPerPage', '10', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(10, 'maxItemsPerPage', '100', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(11, 'minSearchChars', '4', NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff`
--

CREATE TABLE `tbl_staff` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_expiry_date` datetime DEFAULT NULL,
  `force_password_change` tinyint(1) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile` text COLLATE utf8_unicode_ci COMMENT '(DC2Type:json_array)',
  `locale` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `open_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `password`, `password_expiry_date`, `force_password_change`, `remember_token`, `profile`, `locale`, `timezone`, `open_id`, `uuid`, `application_key`, `added_at`, `added_by`, `edited_at`, `edited_by`, `is_deleted`, `version`) VALUES
(1, 'sysadmin', 'sysadmin@example.com', '$2y$10$2EwNXNoIK9fBdvbx59O.Xejy.MS2Grv0VzKudwfrkH.0H6tCF5q5m', NULL, 1, 'PZfXptdDOP', '{"DisplayName":"Dr. Deshawn Kilback V","Photo":"\\/uploads\\/no_photo.jpg","About":"Doloremque repudiandae omnis eum autem iste. Magni culpa atque fugiat. Beatae rerum eos quam cum."}', NULL, NULL, NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:46:49', NULL, 0, 1),
(2, 'demo', 'demo@example.com', '$2y$10$yZW00VGHXKlnD8fB4q9eeuwG6ppzLwyEYSfWzJeFyP5xGwZOrpblq', NULL, 1, 'CbvsxFdvoI', '{"DisplayName":"Dr. Arne Thiel Jr.","Photo":"\\/uploads\\/no_photo.jpg","About":"Non tenetur doloribus optio repellendus hic reiciendis illo. Dolor quia voluptas nam a ex natus."}', NULL, NULL, NULL, NULL, 'uV3tbdxO12KrSJgN7mjbOQvXX69Wn3oL', '2016-11-22 16:46:49', NULL, '2016-11-22 16:51:11', 'demo', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_expiry_date` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `force_password_change` tinyint(1) DEFAULT NULL,
  `profile` text COLLATE utf8_unicode_ci COMMENT '(DC2Type:json_array)',
  `locale` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uuid` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `application_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  `added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_roles`
--

CREATE TABLE `tbl_users_roles` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `is_primary` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_role`
--

CREATE TABLE `tbl_user_role` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `is_primary` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_role`
--

INSERT INTO `tbl_user_role` (`user_id`, `role_id`, `is_primary`) VALUES
(1, 1, 1),
(2, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_audit`
--
ALTER TABLE `tbl_audit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_currency`
--
ALTER TABLE `tbl_currency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_language`
--
ALTER TABLE `tbl_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lookup`
--
ALTER TABLE `tbl_lookup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_media`
--
ALTER TABLE `tbl_media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_permission`
--
ALTER TABLE `tbl_permission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_permissions`
--
ALTER TABLE `tbl_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_province`
--
ALTER TABLE `tbl_province`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_role`
--
ALTER TABLE `tbl_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_roles_permissions`
--
ALTER TABLE `tbl_roles_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `IDX_70C32ED1D60322AC` (`role_id`),
  ADD KEY `IDX_70C32ED1FED90CCA` (`permission_id`);

--
-- Indexes for table `tbl_role_permission`
--
ALTER TABLE `tbl_role_permission`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `IDX_B151AD08D60322AC` (`role_id`),
  ADD KEY `IDX_B151AD08FED90CCA` (`permission_id`);

--
-- Indexes for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users_roles`
--
ALTER TABLE `tbl_users_roles`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `IDX_D6286A16A76ED395` (`user_id`),
  ADD KEY `IDX_D6286A16D60322AC` (`role_id`);

--
-- Indexes for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `IDX_6860A930A76ED395` (`user_id`),
  ADD KEY `IDX_6860A930D60322AC` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_audit`
--
ALTER TABLE `tbl_audit`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_currency`
--
ALTER TABLE `tbl_currency`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_language`
--
ALTER TABLE `tbl_language`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_lookup`
--
ALTER TABLE `tbl_lookup`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_media`
--
ALTER TABLE `tbl_media`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_permission`
--
ALTER TABLE `tbl_permission`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_province`
--
ALTER TABLE `tbl_province`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_role`
--
ALTER TABLE `tbl_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_roles_permissions`
--
ALTER TABLE `tbl_roles_permissions`
  ADD CONSTRAINT `FK_70C32ED1D60322AC` FOREIGN KEY (`role_id`) REFERENCES `tbl_roles` (`id`),
  ADD CONSTRAINT `FK_70C32ED1FED90CCA` FOREIGN KEY (`permission_id`) REFERENCES `tbl_permissions` (`id`);

--
-- Constraints for table `tbl_role_permission`
--
ALTER TABLE `tbl_role_permission`
  ADD CONSTRAINT `FK_B151AD08D60322AC` FOREIGN KEY (`role_id`) REFERENCES `tbl_role` (`id`),
  ADD CONSTRAINT `FK_B151AD08FED90CCA` FOREIGN KEY (`permission_id`) REFERENCES `tbl_permission` (`id`);

--
-- Constraints for table `tbl_users_roles`
--
ALTER TABLE `tbl_users_roles`
  ADD CONSTRAINT `FK_D6286A16A76ED395` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `FK_D6286A16D60322AC` FOREIGN KEY (`role_id`) REFERENCES `tbl_roles` (`id`);

--
-- Constraints for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  ADD CONSTRAINT `FK_6860A930A76ED395` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`),
  ADD CONSTRAINT `FK_6860A930D60322AC` FOREIGN KEY (`role_id`) REFERENCES `tbl_role` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
